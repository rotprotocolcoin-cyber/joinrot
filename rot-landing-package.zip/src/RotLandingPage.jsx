import React, { useEffect, useState } from 'react';

export default function RotLandingPage() {
  const [count, setCount] = useState(999123111);
  const [glitch, setGlitch] = useState(false);
  const [copied, setCopied] = useState(false);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    const counter = setInterval(() => setCount((c) => c + Math.floor(Math.random() * 9) + 1), 1200);
    const glitcher = setInterval(() => setGlitch((g) => !g), 2200);
    const boot = setTimeout(() => setBooting(false), 3200);
    return () => {
      clearInterval(counter);
      clearInterval(glitcher);
      clearTimeout(boot);
    };
  }, []);

  const copyCA = async () => {
    await navigator.clipboard.writeText('6cod81CaFnZs91KUL6vYgsbZfLzHdYmfUMBXbtLwCX8Z');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (booting) {
    return (
      <div className="min-h-screen bg-black text-green-400 flex items-center justify-center font-mono text-lg px-6">
        <div className="space-y-4 max-w-xl">
          <div>&gt; INITIALIZING ROT.EXE...</div>
          <div>&gt; INTERNET POISONING LOADED</div>
          <div>&gt; BRAIN DAMAGE DETECTED</div>
          <div>&gt; ENTERING PSYCHOSIS...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative selection:bg-fuchsia-500/40">
      <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-900/20 via-black to-green-900/20" />
      <div className="absolute inset-0 opacity-10" style={{backgroundImage:'linear-gradient(rgba(255,255,255,0.08) 1px, transparent 1px)',backgroundSize:'100% 4px'}} />
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,rgba(255,0,168,0.12),transparent_40%)]" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-2 h-2 bg-fuchsia-400 rounded-full animate-ping" />
        <div className="absolute top-1/3 right-24 w-3 h-3 bg-green-400 rounded-full animate-pulse" />
      </div>
      <div className="absolute top-24 right-10 hidden lg:block rotate-2 bg-zinc-950 border border-green-500/50 rounded-2xl p-4 font-mono text-xs shadow-2xl animate-pulse">
        <div className="text-green-400 mb-2">SYSTEM INFECTED</div>
        <div>IQ LOSS DETECTED...</div>
      </div>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-10">
        <header className="flex justify-between items-center mb-12 border-b border-zinc-800 pb-6">
          <div>
            <div className={`text-4xl font-black tracking-[0.35em] ${glitch ? 'text-fuchsia-400' : 'text-white'}`}>$ROT</div>
          </div>
          <div className="flex gap-3">
            <a href="https://x.com/ROTMemecoin" target="_blank" rel="noreferrer" className="px-4 py-2 border border-fuchsia-500 rounded-xl">X</a>
            <a href="https://t.me/jointherot" target="_blank" rel="noreferrer" className="px-4 py-2 border border-green-400 rounded-xl">TELEGRAM</a>
          </div>
        </header>

        <section className="grid lg:grid-cols-2 gap-10 items-center min-h-[70vh]">
          <div>
            <div className="inline-block border border-red-500 px-3 py-1 rounded-full text-xs mb-4 animate-pulse">WARNING // INTERNET POISONING TOKENIZED</div>
            <h1 className={`text-6xl md:text-8xl font-black leading-none mb-6 ${glitch ? 'translate-x-1 text-fuchsia-300' : ''}`}>JOIN<br/>THE ROT</h1>
            <p className="text-xl text-zinc-300 mb-8 max-w-xl">The most terminally online memecoin ever created. No utility. No roadmap. No cure.</p>
            <div className="flex flex-wrap gap-4 mb-8">
              <a href="https://t.me/jointherot" target="_blank" rel="noreferrer" className="px-6 py-4 rounded-2xl bg-fuchsia-600 font-bold">JOIN THE ROT</a>
              <button className="px-6 py-4 rounded-2xl border border-green-400 text-green-300 font-bold">BUY $ROT // COMING SOON</button>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-sm font-mono break-all">
              <div>CA: 6cod81CaFnZs91KUL6vYgsbZfLzHdYmfUMBXbtLwCX8Z</div>
              <button onClick={copyCA} className="mt-3 px-4 py-2 rounded-xl border border-fuchsia-500">
                {copied ? 'COPIED ☣️' : 'COPY CA'}
              </button>
            </div>
          </div>
          <div className="grid gap-5">
            <div className="bg-zinc-950 border border-fuchsia-700 rounded-3xl p-6">
              <div className="text-5xl md:text-6xl font-black text-green-400">{count.toLocaleString()}</div>
              <div className="text-zinc-400 mt-2">brain cells lost</div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
